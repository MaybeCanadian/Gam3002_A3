exe in folder should be good to run.
Controls are displayed in game.
My best time is 1:05 left on the clock.