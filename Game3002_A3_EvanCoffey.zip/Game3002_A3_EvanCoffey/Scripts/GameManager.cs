using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    [Header("UI")]
    public GameObject GameUI;
    public GameObject FailureUI;
    public GameObject GameSetUI;
    public GameObject CompleteUI;
    public GameObject KeyRequiredUI;
    public GameObject ReadyCanvas;

    [Header("Image")]
    public GameObject KeyImage;
    public GameObject ReadyImage;
    public GameObject GoImage;

    [Header("Sounds")]
    public AudioSource Clipaud;
    public AudioClip FailureClip;
    public AudioClip GameClip;
    public AudioClip CompleteClip;
    public AudioSource DeathAud;
    public AudioClip ReadyClip;
    public AudioClip GoClip;

    public bool GameRunning = false;

    // Start is called before the first frame update
    void Start()
    {
        Time.timeScale = 1.0f;
        GameUI.SetActive(false);
        FailureUI.SetActive(false);
        GameSetUI.SetActive(false);
        CompleteUI.SetActive(false);
        KeyRequiredUI.SetActive(false);
        KeyImage.SetActive(false);
        GoImage.SetActive(false);

        ReadyCanvas.SetActive(true);
        ReadyImage.SetActive(true);
        
        GameRunning = false;
        StartCoroutine("Intro");
    }

    IEnumerator Intro()
    {
        Clipaud.clip = ReadyClip;
        Clipaud.Play();

        yield return new WaitForSeconds(3);

        ReadyImage.SetActive(false);
        GoImage.SetActive(true);
        Clipaud.clip = GoClip;
        Clipaud.Play();

        yield return new WaitForSeconds(1);
        ReadyCanvas.SetActive(false);
        GameUI.SetActive(true);

        GameRunning = true;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void GameOver()
    {
        DeathAud.Play();
        Time.timeScale = 0.0f;
        Clipaud.clip = FailureClip;
        Clipaud.Play();
        FailureUI.SetActive(true);
        GameUI.SetActive(false);
        CompleteUI.SetActive(false);
        GameSetUI.SetActive(false);
        KeyRequiredUI.SetActive(false);
        GameRunning = false;
    }

    public void KeyRequired()
    {
        KeyRequiredUI.SetActive(true);
    }

    public void RemoveKeyRequired()
    {
        KeyRequiredUI.SetActive(false);
    }

    public void doorOpen()
    {
        KeyImage.SetActive(false);
    }

    public void CollectKey()
    {
        KeyImage.SetActive(true);
    }

    public void OnRestart()
    {

            SceneManager.LoadScene(0);
    }

    public void OutOfTime()
    {
        Time.timeScale = 0.0f;
        Clipaud.clip = GameClip;
        Clipaud.Play();
        CompleteUI.SetActive(false);
        GameUI.SetActive(false);
        KeyRequiredUI.SetActive(false);
        FailureUI.SetActive(false);
        GameSetUI.SetActive(true);
        GameRunning = false;
    }

    public void Winner()
    {
        Time.timeScale = 0.0f;
        Clipaud.clip = CompleteClip;
        Clipaud.Play();
        CompleteUI.SetActive(true);
        GameUI.SetActive(true);
        KeyRequiredUI.SetActive(false);
        FailureUI.SetActive(false);
        GameSetUI.SetActive(false);
        GameRunning = false;
    }

    public void OnQuit()
    {
        Application.Quit();
    }
}
