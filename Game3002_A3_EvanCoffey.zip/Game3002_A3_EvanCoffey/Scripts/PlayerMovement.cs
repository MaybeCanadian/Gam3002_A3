using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMovement : MonoBehaviour
{
    private Rigidbody rb;
    private Animator anim;
    public Vector3 DustOffset;
    private GameManager gm;

    [Header("Audios")]
    public AudioSource JumpAud;
    public AudioSource Jump2Aud;
    public AudioSource DodgeAud;
    public AudioSource WallAud;
    public AudioSource PickUpAudio;
    public AudioSource RunAud;
    public AudioSource LandAud;
    public AudioSource WallHitAud;


    [Header("Movement Bools")]
    public bool OnGround;
    public bool CanWallJump;
    public bool CanDoubleJump;
    public bool IsDodging;

    [Header("Movement Information")]
    public Vector3 WallNormal;
    public Vector2 v;
    public Vector3 MaxSpeed;

    private Vector3 StoredMaxSpeed;


   [Header("Forces")]
    public float JumpForce;
    public float DoubleJumpForce;
    public Vector2 WallJumpForce;
    public float WalkSpeed;
    public Vector2 DodgeForce;

    private float storedWalkForce;


    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        anim = GetComponent<Animator>();
        StoredMaxSpeed = MaxSpeed;
        storedWalkForce = WalkSpeed;
        gm = GameObject.Find("GameManager").GetComponent<GameManager>();
        StartCoroutine("waitToStart");
    }

    IEnumerator waitToStart() //this is to allow for the intro ready and go to play
    {
        Debug.Log("Start");
        anim.Play("Idle");
        OnGround = false;
        CanWallJump = false;
        CanDoubleJump = false;
        IsDodging = false;
        rb.isKinematic = true;

        while (gm.GameRunning == false)
        {
            yield return null;
        }

        rb.isKinematic = false;
        StopCoroutine("waitToStart");
    }

    // Update is called once per frame
    private void FixedUpdate()
    {
        if (!IsDodging)
        {
            if (!(Mathf.Abs(rb.velocity.x) > StoredMaxSpeed.x))
            {
                if(v.x != 0 && OnGround)
                {
                    anim.Play("Run");
                    if (!RunAud.isPlaying)
                    {
                        RunAud.Play();
                    }
                }
                else if(OnGround)
                {
                    anim.Play("Idle");
                    RunAud.Stop();
                }
                rb.AddForce(Vector3.right * v.x * storedWalkForce);
            }
        }

    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Ground")
        {
            if (OnGround == false)
            {
                LandAud.Play();
            }
            OnGround = true;
        }
        else if (collision.gameObject.tag == "Wall")
        {
            if (OnGround == false)
            {
                WallNormal = collision.contacts[0].normal;

                if (CanWallJump == false)
                {
                    WallHitAud.Play();
                }
                CanWallJump = true;
            }
        }
        else if (collision.gameObject.tag == "Spikes")
        {
            gm.GameOver();
            gameObject.SetActive(false);
        }
        else if (collision.gameObject.tag == "Door")
        {
            if (OnGround == false)
            {
                WallHitAud.Play();
            }
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        if(collision.gameObject.tag == "Ground")
        {
            OnGround = false;
            CanDoubleJump = true;
            RunAud.Stop();
        }
        if(collision.gameObject.tag == "Wall")
        {
            CanWallJump = false;
        } 
    }

    private void OnCollisionStay(Collision collision)
    {
        if(collision.gameObject.tag == "Ground")
        {
            OnGround = true;
            CanWallJump = false;
            CanDoubleJump = false;
        }
    }

    public void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Spikes")
        {
            gm.GameOver();
            gameObject.SetActive(false);
        }
        else if(other.tag == "Speed")
        {
            SpeedChangeTrap script = other.GetComponent<SpeedChangeTrap>();
            if(script)
            {
                StoredMaxSpeed.x = script.NewMaxSpeed;
                storedWalkForce = script.NewSpeedForce;
            }
        }
        else if(other.tag == "Key")
        {
            gm.CollectKey();
            PickUpAudio.Play();
            other.gameObject.SetActive(false);
        }
        else if(other.tag == "Finish")
        {
            RunAud.Stop();
            gm.Winner();
        }
    }

    public void OnTriggerExit(Collider other)
    {
        if(other.tag == "Speed")
        {
            SpeedChangeTrap script = other.GetComponent<SpeedChangeTrap>();
            if (script)
            {
                StoredMaxSpeed.x = MaxSpeed.x;
                storedWalkForce = WalkSpeed;
            }
        }
    }

    public void OnJump()
    {
        if (!IsDodging)
        {
            if (OnGround)
            {
                rb.AddForce(Vector3.up * JumpForce);
                CanDoubleJump = true;
                OnGround = false;
                anim.Play("Jump");
                JumpAud.Play();
                RunAud.Stop();
            }
            else if (CanWallJump)
            {
                rb.AddForce(Vector3.up * WallJumpForce.y + WallNormal * WallJumpForce.x);
                CanDoubleJump = false;
                CanWallJump = false;
                anim.Play("Jump");
                WallAud.Play();
                RunAud.Stop();
            }
            else if (CanDoubleJump)
            {
                rb.AddForce(Vector3.up * DoubleJumpForce);
                CanDoubleJump = false;
                anim.Play("DoubleJump");
                Jump2Aud.Play();
                RunAud.Stop();
            }
        }
    }

    public void OnMove(InputValue input)
    {
       v = input.Get<Vector2>();

        if(v.x == 1)
        {
            transform.rotation = new Quaternion(0, 0, 0, 1);
        }
        else if(v.x == -1)
        {
            transform.rotation = new Quaternion(0, 180, 0, 1);
        }
    }

    public void OnDescend()
    {
        rb.AddForce(Vector3.up * -1.0f * storedWalkForce);
    }

    public void OnDodge()
    {
        if (IsDodging == false && gm.GameRunning)
        {
            anim.Play("Dodge");
            IsDodging = true;
            rb.AddForce(Vector3.up * v.y * DodgeForce.y + Vector3.right * v.x * DodgeForce.x);
            DodgeAud.Play();
            RunAud.Stop();
        }
    }


    public void OnJumpAnimDone()
    {
        anim.Play("Idle");
        RunAud.Stop();
    }

    public void OnDoubleJumpAnimDOne()
    {
        anim.Play("Idle");
        RunAud.Stop();
    }

    public void OnDodgeAnimDone()
    {
        if(OnGround && v.x != 0)
        {
            if(!RunAud.isPlaying)
            {
                RunAud.Play();
            }
            anim.Play("Run");
        }
        else
        {
            anim.Play("Idle");
        }
        IsDodging = false;
    }
}
