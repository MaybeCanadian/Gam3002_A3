using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WindMillTrap : MonoBehaviour
{
    private Rigidbody rb;
    public float speed = 20;
    public float MaxSpeed = 20;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.maxAngularVelocity = MaxSpeed;
    }

    private void FixedUpdate()
    {
        rb.AddTorque(new Vector3(speed, 0, 0));
    }
}
