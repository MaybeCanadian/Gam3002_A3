using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera : MonoBehaviour
{
    public Transform FollowTarget;
    public float smoothSpeed = 0.125f;
    public Vector3 CameraOffset;

    public void Start()
    {
        transform.position = FollowTarget.position + CameraOffset;

        transform.LookAt(FollowTarget);
    }

    private void FixedUpdate()
    {

        Vector3 DesiredPosition = FollowTarget.position + CameraOffset;
        Vector3 SmoothedPosition = Vector3.Lerp(transform.position, DesiredPosition, smoothSpeed);
        transform.position = SmoothedPosition;

        transform.LookAt(FollowTarget);
   
    }
}
