using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Door : MonoBehaviour
{
    public GameObject Key;
    GameManager gm;
    private bool open = false;
    private Rigidbody rb;
    private AudioSource aud;

    public float StartPos = 0.0f;
    public float OpenPos = 90.0f;
    public float hitStrength = 100;
    public float openDamp = 150f;

    private HingeJoint hinge;
    // Start is called before the first frame update

    private void Start()
    {
        gm = GameObject.Find("GameManager").GetComponent<GameManager>();
        aud = GetComponent<AudioSource>();
        rb = GetComponent<Rigidbody>();
        open = false;
        hinge = GetComponent<HingeJoint>();
        hinge.useSpring = true;
    }

    private void Update()
    {
        JointSpring spring = new JointSpring();
        spring.spring = hitStrength;
        spring.damper = openDamp;
        if (open)
        {
            spring.targetPosition = openDamp;
        }
        else
        {
            spring.targetPosition = StartPos;
        }

        hinge.spring = spring;
        hinge.useLimits = true;

    }

    private void OnTriggerEnter(Collider other)
    {
        if (open == false)
        {
            if (other.tag == "Player")
            {
                if (Key.activeInHierarchy)
                {
                    gm.KeyRequired();
                }
                else
                {
                    gm.doorOpen();
                    aud.Play();
                    open = true;
                }
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (open == false)
        {
            if (other.tag == "Player")
            {
                gm.RemoveKeyRequired();
            }
        }
    }
}
