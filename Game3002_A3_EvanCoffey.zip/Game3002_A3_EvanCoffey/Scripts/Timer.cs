using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{

    private GameManager gm;

    public Text MinutesText;
    public Text SecondsText;
    public Text MileSecondsText;

    public float MinutesLeft = 2;
    public float SecondsLeft = 0;
    public float MileSecondsLeft = 0;
    // Start is called before the first frame update
    void Start()
    {

        gm = GameObject.Find("GameManager").GetComponent<GameManager>();
        StartCoroutine("waitToStart");
    }

    IEnumerator waitToStart()
    {
        while(gm.GameRunning == false)
        {
            yield return null;

        }

        updateText();
        StartCoroutine("TickDown");
        StopCoroutine("waitToStart");
    }

    IEnumerator TickDown()
    {
        while(MinutesLeft > -1)
        {
            yield return new WaitForEndOfFrame();
            MileSecondsLeft -= Time.deltaTime * 100;
            if(MileSecondsLeft < 0)
            {
                MileSecondsLeft = 99 - (Time.deltaTime - MileSecondsLeft);
                SecondsLeft--;
                if(SecondsLeft < 0)
                {
                    SecondsLeft = 59;
                    MinutesLeft--;
                }
            }

            updateText();
        }

        MinutesLeft = 0;
        SecondsLeft = 0;
        MileSecondsLeft = 0;
        updateText();
        OutofTime();
        yield break;
    }

    private void updateText() //makes sure we keep the zero when number is below 10
    {
        if (MinutesLeft > 9)
        {
            MinutesText.text = MinutesLeft.ToString();
        }
        else
        {
            MinutesText.text = "0" + MinutesLeft;
        }
        if (SecondsLeft > 9)
        {
            SecondsText.text = SecondsLeft.ToString();
        }
        else
        {
            SecondsText.text = "0" + SecondsLeft.ToString();
        }

        int tempMile = (int)MileSecondsLeft;

        if (tempMile > 9)
        {
            MileSecondsText.text = tempMile.ToString();
        }
        else
        {
            MileSecondsText.text = "0" + tempMile.ToString();
        }
    }

    private void OutofTime()
    {
        StopCoroutine("TickDown");
        gm.OutOfTime();
    }

    public void StopTimer()
    {
        StopCoroutine("TickDown");
    }
}
